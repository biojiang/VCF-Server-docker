#!/usr/bin/perl -w
use strict;
use warnings;


if(not -e "/data/users/admin")
{
	system("mkdir -p /data/users/admin");
}
if(not -e "/data/users/public/example")
{
        system("mkdir -p /data/users/public/example");
}
if(not -e "/data/logs/")
{
        system("mkdir -p /data/logs/");
}

if(not -e "/data/db")
{
        system("mkdir -p /data/db && chown -R mongodb:mongodb /data/db");
}
if(not -e "/data/configdb")
{
        system("mkdir -p /data/configdb && chown -R mongodb:mongodb /data/configdb");
}
system("chmod -R 777 /data");
exit(0);
