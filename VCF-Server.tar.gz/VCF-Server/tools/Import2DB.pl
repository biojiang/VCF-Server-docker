#!/usr/bin/perl -w
use strict;
use warnings;
#use Bio::DB::HTS::VCF;
#use JSON;
#use Data::GUID;
use Encode; 
use MongoDB;
use Digest::MD5;
#use MIME::Base64;


my $filename = decode_utf8($ARGV[0]);
my $line_num = 0;
my $public = $ARGV[5];
my $dir = $ARGV[1];
my $desc = decode_utf8($ARGV[3]);
my $genome_version = $ARGV[4];
my $user = $ARGV[2];


my $tool = "/usr/local/apache2/cgi-bin/VCF-Server/tools/ImportVCF2MongoDB";

my $vcfid = Digest::MD5->new->add($dir.$filename)->hexdigest();
my $db = 'db_'.Digest::MD5->new->add($user)->hexdigest();
my $tab = 'tab_'.$vcfid;
my $coll = &mongodb_helper('VCF','user',0);
if(&CheckField($coll,{'__owner'=>$user,'__vcfid'=>$vcfid}) != 0)
{
	#print "$filename exists!<br>";
	print '{"res":2}'."\n";
	exit;
}
my $base = "/data/users/".$user.'/'.$dir.'/';
if(not -e $base.$filename)
{
	print "$filename not exists!<br>";
	print '{"res":0}'."\n";
	exit;
}
my %stat = ();
$stat{'percent'} = 0;
$stat{'loaded'} = 0;
$stat{'type'} = 'Import2DB';
$stat{'status'} = 'Starting';
$stat{'prog'} = 'Import2DB';
&WriteStat($user,$filename,$vcfid,$dir,\%stat);


my $filepath = $base.$filename;

my $lines = 0;
if($filename =~ /\.gz$/)
{
	$lines = `zcat $filepath|wc -l`;
}
else
{
	$lines = `wc -l $filepath`;
}
my @tmp = split/\s/,$lines;
$line_num = $tmp[0];
my %range = ();
my $loaded = 0;
my $bulk_size = 7000;
my $cmd = "$tool $filename 2 $db $tab $user $public $genome_version $bulk_size $dir $vcfid $line_num 1 $filepath";

my $variant_num = `$cmd`;
$loaded = $line_num;
$stat{'percent'} = 99.99;
$stat{'loaded'} = $loaded;
$stat{'type'} = 'Import2DB';
$stat{'status'} = 'Indexing';
&WriteStat($user,$filename,$vcfid,$dir,\%stat);

$coll = &mongodb_helper($db,$tab,1);
my $res = $coll->indexes->create_one(['CHROM'=>1,'POS'=>1],{background=>1});
$res = $coll->indexes->create_one(['CHROM'=>1],{background=>1});
$res = $coll->indexes->create_one(['POS'=>1],{background=>1});



$coll = &mongodb_helper('VCF','user',0);
$coll->insert_one({'__owner'=>$user,'__vcfid'=>$vcfid,'__genome_version'=>$genome_version,'__dbname'=>$db,'__tabname'=>$tab,'__filename'=>$filename,'__variants'=>$variant_num,'__filedir'=>$dir,'__description'=>$desc,'__date'=>&getTime()});

$stat{'percent'} = 100;
$stat{'loaded'} = $loaded;
$stat{'type'} = 'Import2DB';
$stat{'status'} = 'Ready';
&WriteStat($user,$filename,$vcfid,$dir,\%stat);
#print $filename," $loaded/$line_num ","100% Load!\n<br>";

sub CheckField()
{
	my $coll = shift;
	my $cond = shift;
	return $coll->count_documents($cond);
	
}

sub WriteStat()
{
	my $owner = shift;
	my $filename = shift;
	my $vcfid = shift;
	my $dir = shift;
	my $stat = shift;
	my $coll = &mongodb_helper('VCF','task',0);
	if(&CheckField($coll,{'__owner'=>$owner,'__vcfid'=>$vcfid}) > 0)
	{
		$coll->replace_one({'__vcfid'=>$vcfid},{'__owner'=>$owner,'__filename'=>$filename,'__vcfid'=>$vcfid,'__filedir'=>$dir,'__date'=>&getTime(),%{$stat}});
	}
	else
	{
		$coll->insert_one({'__owner'=>$owner,'__filename'=>$filename,'__vcfid'=>$vcfid,'__filedir'=>$dir,'__date'=>&getTime(),%{$stat}});
	}
	
}

sub getTime()
{
        my ($sec,$min,$hour,$mday,$mon,$year,$wday,$yday,$isdst) = localtime;
        $year += 1900;
        $mon += 1;
        my $datetime = sprintf ("%d/%02d/%02d %02d:%02d:%02d", $year,$mon,$mday,$hour,$min,$sec);
        return  $datetime;

}
sub mongodb_helper()
{
	my $db_name = shift;
	my $tab_name = shift;
	my $type = shift;
	my $client;
	my $host = "mongodb://127.0.0.1:27017";
	if($type == 1)
	{
		$client = MongoDB::MongoClient->new(socket_timeout_ms=>-1,host=>$host);
	}
	else
	{
		$client = MongoDB::MongoClient->new(host=>$host);
	}
	$client->connect;
	my $db = $client->get_database($db_name);
	my $coll = $db->get_collection($tab_name);
	$coll->with_codec(prefer_numeric => 1);
	return $coll;

}
