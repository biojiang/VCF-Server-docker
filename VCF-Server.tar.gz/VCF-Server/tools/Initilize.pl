#!/usr/bin/perl -w
use strict;
use warnings;
use MongoDB;
use Digest::MD5;


open LIST,"</etc/user.txt";

my $coll = &mongodb_helper('USER','user');
while(my $line = <LIST>)
{
	chomp $line;
	my @arr = split/\:/,$line;
	my $user = $arr[0];
	if(&CheckField($coll,{"user"=>$user}) == 0)
	{
		my $psw = Digest::MD5->new->add($arr[1])->hexdigest();
		$coll->insert_one({'user'=>$user,'password'=>$psw,'date'=>&getTime()});
		if(not -e "/data/users/$user")
		{
			system("mkdir -p /data/users/$user");
		}
	}
	else
	{
		next;
	}
}

sub CheckField()
{
	my $coll = shift;
	my $cond = shift;
	return $coll->count_documents($cond);

}

sub getTime()
{
        my ($sec,$min,$hour,$mday,$mon,$year,$wday,$yday,$isdst) = localtime;
        $year += 1900;
        $mon += 1;
        my $datetime = sprintf ("%d/%02d/%02d %02d:%02d:%02d", $year,$mon,$mday,$hour,$min,$sec);
        return  $datetime;

}


sub mongodb_helper()
{
	my $db_name = shift;
	my $tab_name = shift;
	my $host = "mongodb://127.0.0.1:27017";
	my $client = MongoDB::MongoClient->new(host=>$host);
	$client->connect;
	my $db = $client->get_database($db_name);
	my $coll = $db->get_collection($tab_name);
	return $coll;
}

