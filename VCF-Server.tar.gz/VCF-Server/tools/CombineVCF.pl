#!/usr/bin/perl -w
use warnings;
use strict;


my $filelist = $ARGV[0];
my $removelist = $ARGV[1];
my @files = split/\,/,$filelist;


my @fh = ();
for my $f(@files)
{
	my $in;
	open $in,"<$f";
	push @fh,$in;
}

my @head = ();
my $title = '';
my %val = ();
for my $in(@fh)
{
	while(my $line = <$in>)
	{
		chomp $line;
		if($line =~ /^\#\#/)
		{
			if(exists $val{$line})
			{
				next;
			}	
			else
			{
				push @head,$line;
				$val{$line} = 1;
			}
	
		}
		else
		{
			$title = $line;
			last;
		}
	}
}
my $tf = $fh[0];
my @body = ();
while(my $line = <$tf>)
{
	chomp $line;
	
	my %bval = ();
	my @arr = split/\t/,$line;
	my @tmp = split/\;/,$arr[7];
	map{$bval{$_} = 1}@tmp;
	for my $f(@fh[1..$#fh])
	{
		$line = <$f>;
		my @arr1 = split/\t/,$line;
		if($arr1[0] eq $arr[0] and $arr1[1] == $arr[1])
		{
			my @tmp1 = split/\;/,$arr1[7];
			map{if(not exists $bval{$_}){$arr[7] .= ';'.$_;$bval{$_} = 1;}}@tmp1;
		}
		else
		{
			print "error!";
			exit;
		}
	}
	push @body,join("\t",@arr);
}

print join("\n",@head),"\n";
print $title,"\n";
print join("\n",@body),"\n";
