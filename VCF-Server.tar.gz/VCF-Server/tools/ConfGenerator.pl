#!/usr/bin/perl -w
use warnings;
use strict;

my $str = $ARGV[0];
my $db = $ARGV[1];
my @arr = split/\,/,$str;
print '[[annotation]]',"\n";
print "file=\"".$db."\"\n";
print 'fields = ["';
print join('","',@arr);
print '"]',"\n";
print 'ops=["';
my @tmp = ();
for(my $i=0;$i<=$#arr;$i++)
{
	push @tmp,'self';
}
print join('","',@tmp);
print '"]',"\n";

if($#ARGV == 2)
{
        my $symol = $ARGV[2];
        for(my $i=0;$i<=$#arr;$i++)
        {
                $arr[$i] = $symol.'_'.$arr[$i];
        }
}

print 'names = ["';
print join('","',@arr);
print '"]',"\n";
