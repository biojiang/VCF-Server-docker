#!/usr/bin/perl -w
use strict;
use warnings;
#use JSON;
use MongoDB;
use Digest::MD5;
use Encode;

my $filename = decode_utf8($ARGV[0]);
my $dir = $ARGV[1];
my $user = $ARGV[2];

my $desc = decode_utf8($ARGV[3]);
my $genome_version = $ARGV[4];
my $public = 0;
my $vcfid = Digest::MD5->new->add($dir.$filename)->hexdigest();

my $tool = "/usr/local/apache2/cgi-bin/VCF-Server/tools/ImportVCF2MongoDB";
my $base = "/data/users/".$user.'/'.$dir.'/';
if(not -e $base.$filename)
{
	print "$filename not exists!<br>";
	return;
}
my $filepath = $base.$filename;

my $db = 'db_'.Digest::MD5->new->add($user)->hexdigest();
my $tab = 'tab_'.$vcfid;
my $bulk_size = 3000;

my $cmd = "$tool $filename 2 $db $tab $user $public $genome_version $bulk_size $dir $vcfid 0 0 $filepath";
my $variant_num = `$cmd`;

my $coll = &mongodb_helper($db,$tab,1);
my $res = $coll->indexes->create_one(['CHROM'=>1,'POS'=>1],{background=>1});
$res = $coll->indexes->create_one(['CHROM'=>1],{background=>1});
$res = $coll->indexes->create_one(['POS'=>1],{background=>1});

$coll = &mongodb_helper('VCF','user',0);
$coll->insert_one({'__owner'=>$user,'__vcfid'=>$vcfid,'__genome_version'=>$genome_version,'__dbname'=>$db,'__tabname'=>$tab,'__filename'=>$filename,'__variants'=>$variant_num,'__filedir'=>$dir,'__description'=>$desc,'__date'=>&getTime()});

sub getTime()
{
        my ($sec,$min,$hour,$mday,$mon,$year,$wday,$yday,$isdst) = localtime;
        $year += 1900;
        $mon += 1;
        my $datetime = sprintf ("%d/%02d/%02d %02d:%02d:%02d", $year,$mon,$mday,$hour,$min,$sec);
        return  $datetime;

}
sub mongodb_helper()
{
	my $db_name = shift;
	my $tab_name = shift;
	my $type = shift;
	my $client;
	my $host = "mongodb://127.0.0.1:27017";
	if($type == 1)
	{
		$client = MongoDB::MongoClient->new(socket_timeout_ms=>-1,host=>$host);
	}
	else
	{
		$client = MongoDB::MongoClient->new(host=>$host);
	}
	$client->connect;
	my $db = $client->get_database($db_name);
	my $coll = $db->get_collection($tab_name);
	$coll->with_codec(prefer_numeric => 1);
	return $coll;

}
