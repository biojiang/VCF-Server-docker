#!/usr/bin/perl
use strict;
use warnings;
use IPC::SysV qw(IPC_PRIVATE S_IRWXU S_IRWXG S_IRWXO IPC_CREAT IPC_NOWAIT);
use IPC::Msg;
use Time::HiRes qw(sleep time);
use List::Util qw(sum);
use threads;
use MongoDB;
use Encode;

my $key_path = "/data/users";
if(not -e $key_path)
{
	print "error!";
	exit;	
}
my $key = IPC::SysV::ftok($key_path,'1');
my $msg = new IPC::Msg($key, 0666 | IPC_CREAT) or die "create message queue: $!";
my $msgtype = 1;
my $msgid = $msg->id();
my $cpu_threshold = 80;
my $max_sleep_time = 15;
my $running = 1;
while($running)
{
	my $buf;
	$msg->rcv($buf, 1024) or die "receive message failed: $!";
	#print $buf;
	if(&CPUUsage(0.3) < 80)
	{
		if($buf =~ /\.Import2DB$/)
		{
			my $t = threads->create(\&worker_import,$buf);
			$t->detach();
		}
		else
		{
			my $t = threads->create(\&worker,$buf);
			$t->detach();
		}
	}
	else
	{
		my $i = 1;
		while(&CPUUsage(0.3) > 80)
		{
			sleep($i);
			$i++;
			if($i > $max_sleep_time)
			{
				$i = 1;
			}
		}
		if($buf =~ /\.Import2DB$/)
                {
                        my $t = threads->create(\&worker_import,$buf);
                        $t->detach();
                }
                else
                {
                        my $t = threads->create(\&worker,$buf);
                        $t->detach();
                }

	}
}
$msg->remove();

sub worker()
{
	my $task_list  = shift;
	open TASK,"<$task_list" or warn $!;
	my $title = <TASK>;
	chomp $title;
	my @item = split/\t/,$title;
	my $user = $item[0];
	my $filename = decode_utf8($item[1]);
	my $vcfid = $item[2];
	my $dir = $item[3];
	my $dbs = decode_utf8($item[4]);
	my %stat = ();
        $stat{'percent'} = 0;
        $stat{'loaded'} = 0;
        $stat{'type'} = 'TaskManager';
        $stat{'status'} = 'Running';
        $stat{'prog'} = 'Import2DB';
        #$stat{'timestamp'} = MongoDB::Timestamp->new("sec" => time(),"inc" => 1);
        my $coll = &mongodb_helper('VCF','task');
        &WriteStat($user,$filename,$vcfid,$dir,\%stat);	
	while(my $line = <TASK>)
	{
		chomp $line;
		my @arr = split/\:/,$line;
		system($arr[1]);
		my $percent = 0;
		my $loaded = 0;
		if($arr[0] =~ /\-/)
		{
			my @tmp = split/\-/,$arr[0];
			$loaded = $tmp[0];
		}
		else
		{
			$loaded = $arr[0];
		}
		$percent = sprintf("%.2f",100*$loaded/$dbs);
		my %stat = ();
		$stat{'percent'} = $percent;
		$stat{'loaded'} = $loaded;
		$stat{'type'} = $arr[2];
		$stat{'status'} = 'Running';
		$stat{'prog'} = 'Import2DB';
		#$stat{'timestamp'} = MongoDB::Timestamp->new("sec" => time(),"inc" => 1);
		&WriteStat($user,$filename,$vcfid,$dir,\%stat);
	}
	$stat{'percent'} = 100;
        $stat{'loaded'} = $dbs;
        $stat{'type'} = 'AnnoVCF';
        $stat{'status'} = 'Ready';
        $stat{'prog'} = 'Import2DB';
        #$stat{'timestamp'} = MongoDB::Timestamp->new("sec" => time(),"inc" => 1);
        &WriteStat($user,$filename,$vcfid,$dir,\%stat);
	
}

sub worker_import()
{
	my $task_list = shift;
	open TASK,"<$task_list" or warn $!;
        my $title = <TASK>;
        chomp $title;
        my @item = split/\:/,$title;
	my $filename = $item[0];
	my $dir = $item[1];
	my $user = $item[2];
	my $vcfid = $item[3];
	my %stat = ();
        $stat{'percent'} = 0;
        $stat{'loaded'} = 0;
        $stat{'type'} = 'TaskManager';
        $stat{'status'} = 'Preparing';
        $stat{'prog'} = 'Import2DB';
        #$stat{'timestamp'} = MongoDB::Timestamp->new("sec" => time(),"inc" => 1);
        my $coll = &mongodb_helper('VCF','task');
        &WriteStat($user,$filename,$vcfid,$dir,\%stat);
	while(my $line = <TASK>)
	{
		chomp $line;
		system($line);	
	}

}

sub CPUUsage()
{
	my $st = shift;
	my ($prev_idle, $prev_total) = qw(0 0);
	open(STAT, '/proc/stat') or die "WTF: $!";
	my $line = <STAT>;
	my @cpu = split /\s+/, $line;
	shift @cpu;
	$prev_idle = $cpu[3];
	$prev_total = sum(@cpu);
	close STAT;
	sleep($st);
	open(STAT, '/proc/stat') or die "WTF: $!";
	$line = <STAT>;
	@cpu = split /\s+/, $line;
	shift @cpu;
	my $idle = $cpu[3];
	my $total = sum(@cpu);
	my $diff_idle = $idle - $prev_idle;
	my $diff_total = $total - $prev_total;
	my $diff_usage = 100 * ($diff_total - $diff_idle) / $diff_total;
	close STAT;
	return sprintf("%0.2f",$diff_usage);

}


sub WriteStat()
{
        my $owner = shift;
        my $filename = shift;
        my $vcfid = shift;
	my $dir = shift;
        my $stat = shift;
        my $coll = &mongodb_helper('VCF','task');
	$coll->replace_one({'__vcfid'=>$vcfid},{'__owner'=>$owner,'__filename'=>$filename,'__vcfid'=>$vcfid,'__filedir'=>$dir,'__date'=>&getTime(),%{$stat}});

}




sub mongodb_helper()
{
        my $db_name = shift;
        my $tab_name = shift;
	my $host = "mongodb://127.0.0.1:27017";
        my $client = MongoDB::MongoClient->new(host=>$host);
        $client->connect;
        my $db = $client->get_database($db_name);
        my $coll = $db->get_collection($tab_name);
        $coll->with_codec(prefer_numeric => 1);
        return $coll;

}

sub getTime()
{
        my ($sec,$min,$hour,$mday,$mon,$year,$wday,$yday,$isdst) = localtime;
        $year += 1900;
        $mon += 1;
        my $datetime = sprintf ("%d-%02d-%02d-%02d-%02d-%02d", $year,$mon,$mday,$hour,$min,$sec);
        return  $datetime;

}
