#!/usr/bin/perl -w
use strict;
use warnings;
use CGI qw(:standard);
use JSON;
use MongoDB;
use Digest::MD5;


print header(-type => 'text/html',
-charset=>'utf-8',
-access_control_allow_origin => '*',
-access_control_allow_headers => 'content-type,X-Requested-With',
-access_control_allow_methods => 'GET,POST,OPTIONS',
-access_control_allow_credentials => 'true',);

my $user = '';
my $psw = '';
my $cgi= new CGI();
if ($cgi->param())
{
	if($cgi->param('user'))
	{
		$user = $cgi->param('user');
	}
	if($cgi->param('passwd'))
	{
		$psw = $cgi->param('passwd');
	}
}

$psw = Digest::MD5->new->add($psw)->hexdigest();

my $coll = &mongodb_helper('USER','user');

if(&CheckField($coll,{'user'=>$user}) > 0)
{
        print '{"res":0}';
        exit;
}
else
{
	$coll->insert_one({'user'=>$user,'password'=>$psw,'date'=>&getTime()});
	print '{"res":1}';
}





sub CheckField()
{
        my $coll = shift;
        my $cond = shift;
        return $coll->count($cond);

}




sub mongodb_helper()
{
        my $db_name = shift;
        my $tab_name = shift;
	my $host = "mongodb://127.0.0.1:27017";
        my $client = MongoDB::MongoClient->new(host=>$host);
        $client->connect;
        my $db = $client->get_database($db_name);
        my $coll = $db->get_collection($tab_name);
        return $coll;
}

sub getTime()
{
        my ($sec,$min,$hour,$mday,$mon,$year,$wday,$yday,$isdst) = localtime;
        $year += 1900;
        $mon += 1;
        my $datetime = sprintf ("%d-%02d-%02d-%02d-%02d-%02d", $year,$mon,$mday,$hour,$min,$sec);
        return  $datetime;

}

